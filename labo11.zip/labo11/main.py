# main.py

from user_interaction import print_message, get_user_input
from data_storage import load_data, save_data
from data_processing import filter_data, sort_data

def main():
    # Call functions from other files as needed
    pass

if __name__ == '__main__':
    main()
